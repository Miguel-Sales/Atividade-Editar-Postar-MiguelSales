// Miguel Francisco da Silva Sales
import React, { useEffect, useState } from "react";
import {
  View,
  Text,
  FlatList,
  StyleSheet,
  ScrollView,
  ImageBackground,
} from "react-native";
import { collection, getDocs } from "firebase/firestore";
import { db } from "../../firebaseConfig";

const MostrarUsuarios = () => {
  const [usuarios, setUsuarios] = useState([]);

  useEffect(() => {
    const buscarUsuarios = async () => {
      try {
        const querySnapshot = await getDocs(collection(db, "real-madrid"));
        const listaUsuarios = querySnapshot.docs.map((doc) => {
          const data = doc.data();
          return {
            id: doc.id,
            ...data,
            nascimento: data.nascimento
              ? new Date(data.nascimento.seconds * 1000).toLocaleDateString("pt-BR")
              : "Data não disponível",
          };
        });
        setUsuarios(listaUsuarios);
      } catch (error) {
        console.error("Erro ao buscar usuários:", error);
      }
    };

    buscarUsuarios();
  }, []);

  return (
    <ImageBackground 
      source={require("../assets/img-fundo.jpg")} 
      style={styles.background}
      resizeMode="cover"
    >
      <ScrollView>
        <View style={styles.box}>
          <Text style={styles.titulo}>Lista de Usuários</Text>
          <FlatList
            data={usuarios}
            keyExtractor={(item) => item.id}
            renderItem={({ item }) => (
              <View style={styles.card}>
                <Text style={styles.nome}>{item.nome}</Text>
                <Text style={styles.texto}>Número da camisa: {item.camisa}</Text>
                <Text style={styles.texto}>Altura do atleta: {item.altura}</Text>
                <Text style={styles.texto}>Data de Nascimento: {item.nascimento}</Text>
              </View>
            )}
          />
        </View>
      </ScrollView>
    </ImageBackground>
  );
};

const styles = StyleSheet.create({
  background: {
    flex: 1,
    width: "100%",
    height: "100%",
    justifyContent: "center",
  },
  box: {
    width: "90%",
    maxWidth: 400,
    backgroundColor: "#fff", 
    padding: 20,
    borderRadius: 10,
    alignSelf: "center",
    marginTop: 25,
    marginBottom: 25,
  },
  titulo: {
    fontSize: 22,
    fontWeight: "bold",
    color: "#333",
    textAlign: "center",
    marginBottom: 20,
  },
  card: {
    backgroundColor: "#e3e3e3",
    padding: 15,
    borderRadius: 8,
    marginBottom: 10,
  },
  nome: {
    fontSize: 18,
    fontWeight: "bold",
    color: "#111",
  },
  texto: {
    fontSize: 16,
    color: "#555",
  },
});

export default MostrarUsuarios;
